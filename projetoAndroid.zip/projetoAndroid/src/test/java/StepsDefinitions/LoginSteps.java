package StepsDefinitions;

import cucumber.api.java.es.Dado;
import screens.LoginScreen;

public class LoginSteps {
    LoginScreen login;

    public LoginSteps() {

        login = new LoginScreen();
    }
    @Dado("^que estou na tela de login$")
    public void queEstouNaTelaDeLogin() {
    login.EstounoLogin();
    }
}
